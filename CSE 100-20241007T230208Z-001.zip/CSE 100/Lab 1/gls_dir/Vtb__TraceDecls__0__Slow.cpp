// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_fst_c.h"


void Vtb___024root__traceDeclTypesSub0(VerilatedFst* tracep) {
}

void Vtb___024root__trace_decl_types(VerilatedFst* tracep) {
    Vtb___024root__traceDeclTypesSub0(tracep);
}

// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb.h for the primary calling header

#include "Vtb__pch.h"
#include "Vtb__Syms.h"
#include "Vtb___024root.h"

VL_INLINE_OPT VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__0\n"); );
    // Body
    vlSymsp->_vm_contextp__->dumpfile(std::string{"dump.fst"});
    vlSymsp->_traceDumpOpen();
    VL_WRITEF_NX("Begin simulation.\n",0);
    vlSelf->tb__DOT__d3 = 0U;
    vlSelf->tb__DOT__d2 = 0U;
    vlSelf->tb__DOT__d1 = 0U;
    vlSelf->tb__DOT__d0 = 0U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 1U;
    vlSelf->tb__DOT__d3 = 0U;
    vlSelf->tb__DOT__d2 = 0U;
    vlSelf->tb__DOT__d1 = 0U;
    vlSelf->tb__DOT__d0 = 1U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 2U;
    vlSelf->tb__DOT__d3 = 0U;
    vlSelf->tb__DOT__d2 = 0U;
    vlSelf->tb__DOT__d1 = 1U;
    vlSelf->tb__DOT__d0 = 0U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 3U;
    vlSelf->tb__DOT__d3 = 0U;
    vlSelf->tb__DOT__d2 = 0U;
    vlSelf->tb__DOT__d1 = 1U;
    vlSelf->tb__DOT__d0 = 1U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 4U;
    vlSelf->tb__DOT__d3 = 0U;
    vlSelf->tb__DOT__d2 = 1U;
    vlSelf->tb__DOT__d1 = 0U;
    vlSelf->tb__DOT__d0 = 0U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 5U;
    vlSelf->tb__DOT__d3 = 0U;
    vlSelf->tb__DOT__d2 = 1U;
    vlSelf->tb__DOT__d1 = 0U;
    vlSelf->tb__DOT__d0 = 1U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 6U;
    vlSelf->tb__DOT__d3 = 0U;
    vlSelf->tb__DOT__d2 = 1U;
    vlSelf->tb__DOT__d1 = 1U;
    vlSelf->tb__DOT__d0 = 0U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 7U;
    vlSelf->tb__DOT__d3 = 0U;
    vlSelf->tb__DOT__d2 = 1U;
    vlSelf->tb__DOT__d1 = 1U;
    vlSelf->tb__DOT__d0 = 1U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 8U;
    vlSelf->tb__DOT__d3 = 1U;
    vlSelf->tb__DOT__d2 = 0U;
    vlSelf->tb__DOT__d1 = 0U;
    vlSelf->tb__DOT__d0 = 0U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 9U;
    vlSelf->tb__DOT__d3 = 1U;
    vlSelf->tb__DOT__d2 = 0U;
    vlSelf->tb__DOT__d1 = 0U;
    vlSelf->tb__DOT__d0 = 1U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 0xaU;
    vlSelf->tb__DOT__d3 = 1U;
    vlSelf->tb__DOT__d2 = 0U;
    vlSelf->tb__DOT__d1 = 1U;
    vlSelf->tb__DOT__d0 = 0U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 0xbU;
    vlSelf->tb__DOT__d3 = 1U;
    vlSelf->tb__DOT__d2 = 0U;
    vlSelf->tb__DOT__d1 = 1U;
    vlSelf->tb__DOT__d0 = 1U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 0xcU;
    vlSelf->tb__DOT__d3 = 1U;
    vlSelf->tb__DOT__d2 = 1U;
    vlSelf->tb__DOT__d1 = 0U;
    vlSelf->tb__DOT__d0 = 0U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 0xdU;
    vlSelf->tb__DOT__d3 = 1U;
    vlSelf->tb__DOT__d2 = 1U;
    vlSelf->tb__DOT__d1 = 0U;
    vlSelf->tb__DOT__d0 = 1U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 0xeU;
    vlSelf->tb__DOT__d3 = 1U;
    vlSelf->tb__DOT__d2 = 1U;
    vlSelf->tb__DOT__d1 = 1U;
    vlSelf->tb__DOT__d0 = 0U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 0xfU;
    vlSelf->tb__DOT__d3 = 1U;
    vlSelf->tb__DOT__d2 = 1U;
    vlSelf->tb__DOT__d1 = 1U;
    vlSelf->tb__DOT__d0 = 1U;
    co_await vlSelf->__VdlySched.delay(1ULL, nullptr, 
                                       "dv/tb.sv", 
                                       31);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb__DOT__unnamedblk1__DOT__i = 0x10U;
    VL_WRITEF_NX("End simulation.\n",0);
    VL_FINISH_MT("dv/tb.sv", 35, "");
    vlSelf->__Vm_traceActivity[2U] = 1U;
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__act(Vtb___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb___024root___eval_triggers__act(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_triggers__act\n"); );
    // Body
    vlSelf->__VactTriggered.set(0U, vlSelf->__VdlySched.awaitingCurrentTime());
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtb___024root___dump_triggers__act(vlSelf);
    }
#endif
}

VL_INLINE_OPT void Vtb___024root___act_sequent__TOP__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_sequent__TOP__0\n"); );
    // Init
    CData/*0:0*/ tb__DOT__hex7seg__DOT___024_;
    tb__DOT__hex7seg__DOT___024_ = 0;
    CData/*0:0*/ tb__DOT__hex7seg__DOT___038_;
    tb__DOT__hex7seg__DOT___038_ = 0;
    // Body
    vlSelf->tb__DOT__hex7seg__DOT___028_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d3)) 
                                                  | (IData)(vlSelf->tb__DOT__d2)));
    vlSelf->tb__DOT__hex7seg__DOT___031_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d3)) 
                                                  | (~ (IData)(vlSelf->tb__DOT__d2))));
    vlSelf->tb__DOT__hex7seg__DOT___023_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d2)) 
                                                  | (IData)(vlSelf->tb__DOT__d3)));
    vlSelf->tb__DOT__hex7seg__DOT___037_ = ((IData)(vlSelf->tb__DOT__d2) 
                                            | (IData)(vlSelf->tb__DOT__d3));
    vlSelf->tb__DOT__hex7seg__DOT___030_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                     | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_))));
    vlSelf->tb__DOT__hex7seg__DOT___033_ = (((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                             | (IData)(vlSelf->tb__DOT__d1)) 
                                            | (IData)(vlSelf->tb__DOT__d0));
    vlSelf->tb__DOT__hex7seg__DOT___035_ = (1U & ((
                                                   (~ (IData)(vlSelf->tb__DOT__d1)) 
                                                   | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)) 
                                                  | (IData)(vlSelf->tb__DOT__d0)));
    vlSelf->tb__DOT__hex7seg__DOT___043_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                     | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_))));
    tb__DOT__hex7seg__DOT___024_ = ((IData)(vlSelf->tb__DOT__hex7seg__DOT___023_) 
                                    | (IData)(vlSelf->tb__DOT__d1));
    vlSelf->tb__DOT__hex7seg__DOT___041_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                     | (IData)(vlSelf->tb__DOT__d1))));
    tb__DOT__hex7seg__DOT___038_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___037_)));
    vlSelf->tb__DOT__hex7seg__DOT___025_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | (IData)(tb__DOT__hex7seg__DOT___024_)));
    vlSelf->tb__DOT__hex7seg__DOT___042_ = ((IData)(tb__DOT__hex7seg__DOT___024_) 
                                            | (IData)(vlSelf->tb__DOT__d0));
    vlSelf->tb__DOT__hex7seg__DOT___039_ = ((IData)(tb__DOT__hex7seg__DOT___038_) 
                                            | (IData)(vlSelf->tb__DOT__d0));
    vlSelf->tb__DOT__hex7seg__DOT___045_ = (1U & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | (IData)(tb__DOT__hex7seg__DOT___038_)));
    vlSelf->tb__DOT__hex7seg__DOT___008_ = ((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_));
    if (vlSelf->tb__DOT__d3) {
        if (vlSelf->tb__DOT__d2) {
            if (vlSelf->tb__DOT__d1) {
                if (vlSelf->tb__DOT__d0) {
                    if (vlSymsp->_vm_contextp__->assertOn()) {
                        if (VL_LIKELY((0x47U != (((
                                                   ((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                   & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                      | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                         | (IData)(vlSelf->tb__DOT__d1)))) 
                                                  << 6U) 
                                                 | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                          & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                             | (IData)(vlSelf->tb__DOT__d0))) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                      & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                         | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                            | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                     << 5U) 
                                                    | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                           & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                         & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                            | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                               | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                        << 4U) 
                                                       | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                             & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                                 | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                                | (IData)(vlSelf->tb__DOT__d0))) 
                                                            & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                               | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                           << 3U) 
                                                          | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                                  & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                               & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                  | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                     | (IData)(vlSelf->tb__DOT__d1)))) 
                                                              << 2U) 
                                                             | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                     | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                        | (IData)(vlSelf->tb__DOT__d1)))) 
                                                                 << 1U) 
                                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                       | (IData)(vlSelf->tb__DOT__d1)) 
                                                                      | (IData)(vlSelf->tb__DOT__d0)) 
                                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                            if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                                VL_WRITEF_NX("[%0t] %%Error: tb.sv:55: Assertion failed in %Ntb: Wrong result for f\n",0,
                                             64,VL_TIME_UNITED_Q(1),
                                             -12,vlSymsp->name());
                                VL_STOP_MT("dv/tb.sv", 55, "");
                            }
                        }
                    }
                } else if (vlSymsp->_vm_contextp__->assertOn()) {
                    if (VL_LIKELY((0x4fU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                               & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                     | (IData)(vlSelf->tb__DOT__d1)))) 
                                              << 6U) 
                                             | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                      & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                         | (IData)(vlSelf->tb__DOT__d0))) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                     | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                        | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                 << 5U) 
                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                     & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                        | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                           | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                    << 4U) 
                                                   | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                         & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                             | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                            | (IData)(vlSelf->tb__DOT__d0))) 
                                                        & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                           | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                       << 3U) 
                                                      | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                                          << 2U) 
                                                         | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                 | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                    | (IData)(vlSelf->tb__DOT__d1)))) 
                                                             << 1U) 
                                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                   | (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__d0)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                        if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                            VL_WRITEF_NX("[%0t] %%Error: tb.sv:54: Assertion failed in %Ntb: Wrong result for e\n",0,
                                         64,VL_TIME_UNITED_Q(1),
                                         -12,vlSymsp->name());
                            VL_STOP_MT("dv/tb.sv", 54, "");
                        }
                    }
                }
            } else if (vlSelf->tb__DOT__d0) {
                if (vlSymsp->_vm_contextp__->assertOn()) {
                    if (VL_LIKELY((0x3dU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                               & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                     | (IData)(vlSelf->tb__DOT__d1)))) 
                                              << 6U) 
                                             | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                      & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                         | (IData)(vlSelf->tb__DOT__d0))) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                     | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                        | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                 << 5U) 
                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                     & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                        | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                           | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                    << 4U) 
                                                   | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                         & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                             | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                            | (IData)(vlSelf->tb__DOT__d0))) 
                                                        & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                           | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                       << 3U) 
                                                      | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                                          << 2U) 
                                                         | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                 | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                    | (IData)(vlSelf->tb__DOT__d1)))) 
                                                             << 1U) 
                                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                   | (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__d0)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                        if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                            VL_WRITEF_NX("[%0t] %%Error: tb.sv:53: Assertion failed in %Ntb: Wrong result for d\n",0,
                                         64,VL_TIME_UNITED_Q(1),
                                         -12,vlSymsp->name());
                            VL_STOP_MT("dv/tb.sv", 53, "");
                        }
                    }
                }
            } else if (vlSymsp->_vm_contextp__->assertOn()) {
                if (VL_LIKELY((0x4eU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                          << 6U) | 
                                         ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                    | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                   | (IData)(vlSelf->tb__DOT__d0))) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                            & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                               | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                  | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                           << 5U) | 
                                          ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                             & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                   | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                            << 4U) 
                                           | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                  & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                 & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                     | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                    | (IData)(vlSelf->tb__DOT__d0))) 
                                                & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                   | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                      | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                               << 3U) 
                                              | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                   & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                      | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                         | (IData)(vlSelf->tb__DOT__d1)))) 
                                                  << 2U) 
                                                 | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                      & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                         | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                            | (IData)(vlSelf->tb__DOT__d1)))) 
                                                     << 1U) 
                                                    | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                           | (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__d0)) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                        VL_WRITEF_NX("[%0t] %%Error: tb.sv:52: Assertion failed in %Ntb: Wrong result for c\n",0,
                                     64,VL_TIME_UNITED_Q(1),
                                     -12,vlSymsp->name());
                        VL_STOP_MT("dv/tb.sv", 52, "");
                    }
                }
            }
        } else if (vlSelf->tb__DOT__d1) {
            if (vlSelf->tb__DOT__d0) {
                if (vlSymsp->_vm_contextp__->assertOn()) {
                    if (VL_LIKELY((0x1fU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                               & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                     | (IData)(vlSelf->tb__DOT__d1)))) 
                                              << 6U) 
                                             | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                      & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                         | (IData)(vlSelf->tb__DOT__d0))) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                     | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                        | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                 << 5U) 
                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                     & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                        | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                           | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                    << 4U) 
                                                   | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                         & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                             | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                            | (IData)(vlSelf->tb__DOT__d0))) 
                                                        & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                           | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                       << 3U) 
                                                      | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                                          << 2U) 
                                                         | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                 | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                    | (IData)(vlSelf->tb__DOT__d1)))) 
                                                             << 1U) 
                                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                   | (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__d0)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                        if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                            VL_WRITEF_NX("[%0t] %%Error: tb.sv:51: Assertion failed in %Ntb: Wrong result for b\n",0,
                                         64,VL_TIME_UNITED_Q(1),
                                         -12,vlSymsp->name());
                            VL_STOP_MT("dv/tb.sv", 51, "");
                        }
                    }
                }
            } else if (vlSymsp->_vm_contextp__->assertOn()) {
                if (VL_LIKELY((0x77U != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                          << 6U) | 
                                         ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                    | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                   | (IData)(vlSelf->tb__DOT__d0))) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                            & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                               | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                  | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                           << 5U) | 
                                          ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                             & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                   | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                            << 4U) 
                                           | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                  & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                 & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                     | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                    | (IData)(vlSelf->tb__DOT__d0))) 
                                                & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                   | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                      | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                               << 3U) 
                                              | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                   & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                      | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                         | (IData)(vlSelf->tb__DOT__d1)))) 
                                                  << 2U) 
                                                 | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                      & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                         | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                            | (IData)(vlSelf->tb__DOT__d1)))) 
                                                     << 1U) 
                                                    | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                           | (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__d0)) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                        VL_WRITEF_NX("[%0t] %%Error: tb.sv:50: Assertion failed in %Ntb: Wrong result for a\n",0,
                                     64,VL_TIME_UNITED_Q(1),
                                     -12,vlSymsp->name());
                        VL_STOP_MT("dv/tb.sv", 50, "");
                    }
                }
            }
        } else if (vlSelf->tb__DOT__d0) {
            if (vlSymsp->_vm_contextp__->assertOn()) {
                if (VL_LIKELY((0x7bU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                          << 6U) | 
                                         ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                    | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                   | (IData)(vlSelf->tb__DOT__d0))) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                            & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                               | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                  | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                           << 5U) | 
                                          ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                             & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                   | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                            << 4U) 
                                           | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                  & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                 & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                     | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                    | (IData)(vlSelf->tb__DOT__d0))) 
                                                & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                   | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                      | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                               << 3U) 
                                              | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                   & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                      | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                         | (IData)(vlSelf->tb__DOT__d1)))) 
                                                  << 2U) 
                                                 | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                      & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                         | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                            | (IData)(vlSelf->tb__DOT__d1)))) 
                                                     << 1U) 
                                                    | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                           | (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__d0)) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                        VL_WRITEF_NX("[%0t] %%Error: tb.sv:49: Assertion failed in %Ntb: Wrong result for 9\n",0,
                                     64,VL_TIME_UNITED_Q(1),
                                     -12,vlSymsp->name());
                        VL_STOP_MT("dv/tb.sv", 49, "");
                    }
                }
            }
        } else if (vlSymsp->_vm_contextp__->assertOn()) {
            if (VL_LIKELY((0x7fU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                       & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                          | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                             | (IData)(vlSelf->tb__DOT__d1)))) 
                                      << 6U) | ((((
                                                   ((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                      & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                         | (IData)(vlSelf->tb__DOT__d0))) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                     | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                        | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                 << 5U) 
                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                     & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                        | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                           | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                    << 4U) 
                                                   | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                         & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                             | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                            | (IData)(vlSelf->tb__DOT__d0))) 
                                                        & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                           | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                       << 3U) 
                                                      | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                                          << 2U) 
                                                         | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                 | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                    | (IData)(vlSelf->tb__DOT__d1)))) 
                                                             << 1U) 
                                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                   | (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__d0)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                    VL_WRITEF_NX("[%0t] %%Error: tb.sv:48: Assertion failed in %Ntb: Wrong result for 8\n",0,
                                 64,VL_TIME_UNITED_Q(1),
                                 -12,vlSymsp->name());
                    VL_STOP_MT("dv/tb.sv", 48, "");
                }
            }
        }
    } else if (vlSelf->tb__DOT__d2) {
        if (vlSelf->tb__DOT__d1) {
            if (vlSelf->tb__DOT__d0) {
                if (vlSymsp->_vm_contextp__->assertOn()) {
                    if (VL_LIKELY((0x70U != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                               & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                  | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                     | (IData)(vlSelf->tb__DOT__d1)))) 
                                              << 6U) 
                                             | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                      & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                         | (IData)(vlSelf->tb__DOT__d0))) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                     | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                        | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                 << 5U) 
                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                     & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                        | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                           | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                    << 4U) 
                                                   | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                         & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                             | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                            | (IData)(vlSelf->tb__DOT__d0))) 
                                                        & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                           | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                       << 3U) 
                                                      | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                                          << 2U) 
                                                         | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                 | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                    | (IData)(vlSelf->tb__DOT__d1)))) 
                                                             << 1U) 
                                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                   | (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__d0)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                        if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                            VL_WRITEF_NX("[%0t] %%Error: tb.sv:47: Assertion failed in %Ntb: Wrong result for 7\n",0,
                                         64,VL_TIME_UNITED_Q(1),
                                         -12,vlSymsp->name());
                            VL_STOP_MT("dv/tb.sv", 47, "");
                        }
                    }
                }
            } else if (vlSymsp->_vm_contextp__->assertOn()) {
                if (VL_LIKELY((0x5fU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                          << 6U) | 
                                         ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                    | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                   | (IData)(vlSelf->tb__DOT__d0))) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                            & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                               | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                  | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                           << 5U) | 
                                          ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                             & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                   | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                            << 4U) 
                                           | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                  & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                 & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                     | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                    | (IData)(vlSelf->tb__DOT__d0))) 
                                                & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                   | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                      | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                               << 3U) 
                                              | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                   & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                      | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                         | (IData)(vlSelf->tb__DOT__d1)))) 
                                                  << 2U) 
                                                 | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                      & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                         | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                            | (IData)(vlSelf->tb__DOT__d1)))) 
                                                     << 1U) 
                                                    | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                           | (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__d0)) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                        VL_WRITEF_NX("[%0t] %%Error: tb.sv:46: Assertion failed in %Ntb: Wrong result for 6\n",0,
                                     64,VL_TIME_UNITED_Q(1),
                                     -12,vlSymsp->name());
                        VL_STOP_MT("dv/tb.sv", 46, "");
                    }
                }
            }
        } else if (vlSelf->tb__DOT__d0) {
            if (vlSymsp->_vm_contextp__->assertOn()) {
                if (VL_LIKELY((0x5bU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                          << 6U) | 
                                         ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                    | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                   | (IData)(vlSelf->tb__DOT__d0))) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                            & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                               | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                  | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                           << 5U) | 
                                          ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                             & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                   | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                            << 4U) 
                                           | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                  & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                 & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                     | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                    | (IData)(vlSelf->tb__DOT__d0))) 
                                                & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                   | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                      | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                               << 3U) 
                                              | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                   & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                      | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                         | (IData)(vlSelf->tb__DOT__d1)))) 
                                                  << 2U) 
                                                 | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                      & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                         | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                            | (IData)(vlSelf->tb__DOT__d1)))) 
                                                     << 1U) 
                                                    | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                           | (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__d0)) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                        VL_WRITEF_NX("[%0t] %%Error: tb.sv:45: Assertion failed in %Ntb: Wrong result for 5\n",0,
                                     64,VL_TIME_UNITED_Q(1),
                                     -12,vlSymsp->name());
                        VL_STOP_MT("dv/tb.sv", 45, "");
                    }
                }
            }
        } else if (vlSymsp->_vm_contextp__->assertOn()) {
            if (VL_LIKELY((0x33U != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                       & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                          | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                             | (IData)(vlSelf->tb__DOT__d1)))) 
                                      << 6U) | ((((
                                                   ((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                      & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                         | (IData)(vlSelf->tb__DOT__d0))) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                     | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                        | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                 << 5U) 
                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                     & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                        | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                           | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                    << 4U) 
                                                   | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                         & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                             | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                            | (IData)(vlSelf->tb__DOT__d0))) 
                                                        & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                           | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                       << 3U) 
                                                      | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                                          << 2U) 
                                                         | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                 | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                    | (IData)(vlSelf->tb__DOT__d1)))) 
                                                             << 1U) 
                                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                   | (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__d0)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                    VL_WRITEF_NX("[%0t] %%Error: tb.sv:44: Assertion failed in %Ntb: Wrong result for 4\n",0,
                                 64,VL_TIME_UNITED_Q(1),
                                 -12,vlSymsp->name());
                    VL_STOP_MT("dv/tb.sv", 44, "");
                }
            }
        }
    } else if (vlSelf->tb__DOT__d1) {
        if (vlSelf->tb__DOT__d0) {
            if (vlSymsp->_vm_contextp__->assertOn()) {
                if (VL_LIKELY((0x79U != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                          << 6U) | 
                                         ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                    | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                   | (IData)(vlSelf->tb__DOT__d0))) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                            & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                               | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                  | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                           << 5U) | 
                                          ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                             & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                   | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                            << 4U) 
                                           | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                  & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                 & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                     | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                    | (IData)(vlSelf->tb__DOT__d0))) 
                                                & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                   | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                      | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                               << 3U) 
                                              | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                   & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                      | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                         | (IData)(vlSelf->tb__DOT__d1)))) 
                                                  << 2U) 
                                                 | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                      & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                         | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                            | (IData)(vlSelf->tb__DOT__d1)))) 
                                                     << 1U) 
                                                    | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                           | (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__d0)) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                        VL_WRITEF_NX("[%0t] %%Error: tb.sv:43: Assertion failed in %Ntb: Wrong result for 3\n",0,
                                     64,VL_TIME_UNITED_Q(1),
                                     -12,vlSymsp->name());
                        VL_STOP_MT("dv/tb.sv", 43, "");
                    }
                }
            }
        } else if (vlSymsp->_vm_contextp__->assertOn()) {
            if (VL_LIKELY((0x6dU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                       & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                          | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                             | (IData)(vlSelf->tb__DOT__d1)))) 
                                      << 6U) | ((((
                                                   ((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                      & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                         | (IData)(vlSelf->tb__DOT__d0))) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                     | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                        | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                 << 5U) 
                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                     & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                        | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                           | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                    << 4U) 
                                                   | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                         & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                             | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                            | (IData)(vlSelf->tb__DOT__d0))) 
                                                        & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                           | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                       << 3U) 
                                                      | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                                          << 2U) 
                                                         | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                 | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                    | (IData)(vlSelf->tb__DOT__d1)))) 
                                                             << 1U) 
                                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                   | (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__d0)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                    VL_WRITEF_NX("[%0t] %%Error: tb.sv:42: Assertion failed in %Ntb: Wrong result for 2\n",0,
                                 64,VL_TIME_UNITED_Q(1),
                                 -12,vlSymsp->name());
                    VL_STOP_MT("dv/tb.sv", 42, "");
                }
            }
        }
    } else if (vlSelf->tb__DOT__d0) {
        if (vlSymsp->_vm_contextp__->assertOn()) {
            if (VL_LIKELY((0x30U != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                       & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                          | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                             | (IData)(vlSelf->tb__DOT__d1)))) 
                                      << 6U) | ((((
                                                   ((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                      & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                         | (IData)(vlSelf->tb__DOT__d0))) 
                                                     & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                  & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                     | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                        | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                 << 5U) 
                                                | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                       & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                     & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                        | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                           | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                    << 4U) 
                                                   | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                         & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                             | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                            | (IData)(vlSelf->tb__DOT__d0))) 
                                                        & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                           | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                       << 3U) 
                                                      | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                              & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                           & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                              | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                                 | (IData)(vlSelf->tb__DOT__d1)))) 
                                                          << 2U) 
                                                         | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                                 | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                    | (IData)(vlSelf->tb__DOT__d1)))) 
                                                             << 1U) 
                                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                                   | (IData)(vlSelf->tb__DOT__d1)) 
                                                                  | (IData)(vlSelf->tb__DOT__d0)) 
                                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
                if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                    VL_WRITEF_NX("[%0t] %%Error: tb.sv:41: Assertion failed in %Ntb: Wrong result for 1\n",0,
                                 64,VL_TIME_UNITED_Q(1),
                                 -12,vlSymsp->name());
                    VL_STOP_MT("dv/tb.sv", 41, "");
                }
            }
        }
    } else if (vlSymsp->_vm_contextp__->assertOn()) {
        if (VL_LIKELY((0x7eU != (((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                    & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                   & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                      | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                         | (IData)(vlSelf->tb__DOT__d1)))) 
                                  << 6U) | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___025_) 
                                                  & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                      | (IData)(vlSelf->tb__DOT__hex7seg__DOT___023_)) 
                                                     | (IData)(vlSelf->tb__DOT__d0))) 
                                                 & (IData)(vlSelf->tb__DOT__hex7seg__DOT___030_)) 
                                                & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                               & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                              & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                 | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                    | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                             << 5U) 
                                            | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___039_) 
                                                   & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                  & (IData)(vlSelf->tb__DOT__hex7seg__DOT___035_)) 
                                                 & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                    | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                       | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                << 4U) 
                                               | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___008_) 
                                                      & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                     & (((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                         | (IData)(vlSelf->tb__DOT__hex7seg__DOT___028_)) 
                                                        | (IData)(vlSelf->tb__DOT__d0))) 
                                                    & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                       | ((~ (IData)(vlSelf->tb__DOT__d1)) 
                                                          | (IData)(vlSelf->tb__DOT__hex7seg__DOT___031_)))) 
                                                   << 3U) 
                                                  | ((((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                           & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                          & (IData)(vlSelf->tb__DOT__hex7seg__DOT___042_)) 
                                                         & (IData)(vlSelf->tb__DOT__hex7seg__DOT___025_)) 
                                                        & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                       & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                          | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___028_) 
                                                             | (IData)(vlSelf->tb__DOT__d1)))) 
                                                      << 2U) 
                                                     | (((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___041_) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___039_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___045_)) 
                                                           & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                          & ((~ (IData)(vlSelf->tb__DOT__d0)) 
                                                             | ((IData)(vlSelf->tb__DOT__hex7seg__DOT___031_) 
                                                                | (IData)(vlSelf->tb__DOT__d1)))) 
                                                         << 1U) 
                                                        | ((((((IData)(vlSelf->tb__DOT__hex7seg__DOT___037_) 
                                                               | (IData)(vlSelf->tb__DOT__d1)) 
                                                              | (IData)(vlSelf->tb__DOT__d0)) 
                                                             & (IData)(vlSelf->tb__DOT__hex7seg__DOT___043_)) 
                                                            & (IData)(vlSelf->tb__DOT__hex7seg__DOT___033_)) 
                                                           & (IData)(vlSelf->tb__DOT__hex7seg__DOT___041_))))))))))) {
            if (VL_UNLIKELY(vlSymsp->_vm_contextp__->assertOn())) {
                VL_WRITEF_NX("[%0t] %%Error: tb.sv:40: Assertion failed in %Ntb: Wrong result for 0\n",0,
                             64,VL_TIME_UNITED_Q(1),
                             -12,vlSymsp->name());
                VL_STOP_MT("dv/tb.sv", 40, "");
            }
        }
    }
}
